`timescale 1ns / 1ps

module RF_ALU_FSM_tb;
    reg clk;
    reg rst;

    parameter IDLE           = 3'b000;
    parameter WRITE_REGS     = 3'b001;
    parameter READ_REGISTERS = 3'b010;
    parameter ALU_EXECUTE    = 3'b011;
    parameter WRITE_BACK     = 3'b100;
    parameter CHECK_BEQ      = 3'b101;
    parameter DONE           = 3'b110;

    reg [2:0] state, next_state;
    reg rf_we;
    reg [4:0] rs1, rs2, rd;
    reg [31:0] writeData;
    wire [31:0] readData1, readData2;

    reg [3:0] alu_ctrl;
    wire [31:0] alu_result;
    wire zero_flag;
    reg [3:0] op_step;

    RegisterFile rf (
        .clk(clk), .rst(rst), .writeEnable(rf_we),
        .rs1(rs1), .rs2(rs2), .rd(rd),
        .writeData(writeData), .readData1(readData1), .readData2(readData2)
    );

    ALU alu (
        .A(readData1), .B(readData2), .ALUControl(alu_ctrl),
        .ALUResult(alu_result), .Zero(zero_flag)
    );

    always #5 clk = ~clk;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= IDLE;
            op_step <= 4'd0;
        end else begin
            state <= next_state;
            if (state == ALU_EXECUTE) begin
                op_step <= op_step + 1;
            end
        end
    end

    always @(*) begin
        next_state = state;
        rf_we = 1'b0;
        rs1 = 5'd0; rs2 = 5'd0; rd = 5'd0;
        writeData = 32'd0;
        alu_ctrl = 4'b0000;

        case (state)
            IDLE: next_state = WRITE_REGS;

            WRITE_REGS: begin
                rf_we = 1'b1;
                if (op_step == 0)      {rd, writeData} = {5'd1, 32'h10101010};
                else if (op_step == 1) {rd, writeData} = {5'd2, 32'h01010101};
                else if (op_step == 2) {rd, writeData} = {5'd3, 32'h00000005};
               
                next_state = (op_step < 2) ? WRITE_REGS : READ_REGISTERS;
            end

            READ_REGISTERS: begin
                rs1 = 5'd1; rs2 = 5'd2;
                next_state = ALU_EXECUTE;
            end

            ALU_EXECUTE: begin
                rs1 = 5'd1; rs2 = 5'd2;
                case (op_step)
                    4'd0: alu_ctrl = 4'b0000; // ADD
                    4'd1: alu_ctrl = 4'b0001; // SUB
                    4'd2: alu_ctrl = 4'b0010; // AND
                    4'd3: alu_ctrl = 4'b0011; // OR
                    4'd4: alu_ctrl = 4'b0100; // XOR
                    4'd5: begin rs2 = 5'd3; alu_ctrl = 4'b0101; end // SLL
                    4'd6: begin rs2 = 5'd3; alu_ctrl = 4'b0110; end // SRL
                endcase
                next_state = WRITE_BACK;
            end

            WRITE_BACK: begin
                rf_we = 1'b1;
                rd = 5'd4 + op_step[2:0];
                writeData = alu_result;
                $display("[INFO] Step %0d: ALU Result %h written to x%0d", op_step, alu_result, rd);
                next_state = (op_step < 6) ? READ_REGISTERS : CHECK_BEQ;
            end

            CHECK_BEQ: begin
                rs1 = 5'd1; rs2 = 5'd2;
                alu_ctrl = 4'b0001;
                $display("[PASS] BEQ Check completed. Zero flag = %b", zero_flag);
                next_state = DONE;
            end

            DONE: $finish;
        endcase
    end

    initial begin
        clk = 0; rst = 1; op_step = 0;
        #15; rst = 0;
    end
endmodule