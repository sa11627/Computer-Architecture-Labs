`timescale 1ns / 1ps

module RegisterFile_tb;
    reg clk;
    reg rst;
    reg writeEnable;
    reg [4:0] rs1;
    reg [4:0] rs2;
    reg [4:0] rd;
    reg [31:0] writeData;
    wire [31:0] readData1;
    wire [31:0] readData2;

    RegisterFile uut (
        .clk(clk),
        .rst(rst),
        .writeEnable(writeEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .writeData(writeData),
        .readData1(readData1),
        .readData2(readData2)
    );

    always #5 clk = ~clk; // 100 MHz clock

    initial begin
        clk = 0;
        rst = 1;
        writeEnable = 0;
        rs1 = 0;
        rs2 = 0;
        rd = 0;
        writeData = 32'h0;

        #12;
        rst = 0;
        #10;

        // Test 1: Write to x5 = 0xDEADBEEF and read back
        @(posedge clk);
        rd = 5'd5;
        writeData = 32'hDEADBEEF;
        writeEnable = 1;
       
        @(posedge clk);
        writeEnable = 0;
        rs1 = 5'd5;
        #2;
        if (readData1 == 32'hDEADBEEF)
            $display("[PASS] Test 1: x5 successfully written and read as 0xDEADBEEF");
        else
            $display("[FAIL] Test 1: Expected 0xDEADBEEF, got %h", readData1);

        // Test 2: Attempt to write to x0 (should remain 0)
        @(posedge clk);
        rd = 5'd0;
        writeData = 32'hFFFFFFFF;
        writeEnable = 1;

        @(posedge clk);
        writeEnable = 0;
        rs1 = 5'd0;
        #2;
        if (readData1 == 32'h0)
            $display("[PASS] Test 2: x0 write ignored, value is 0");
        else
            $display("[FAIL] Test 2: x0 modified! Got %h", readData1);

        // Test 3: Simultaneous dual read ports (rs1 = 5, rs2 = 0)
        rs1 = 5'd5;
        rs2 = 5'd0;
        #2;
        if ((readData1 == 32'hDEADBEEF) && (readData2 == 32'h0))
            $display("[PASS] Test 3: Dual read successful");
        else
            $display("[FAIL] Test 3: Dual read mismatch");

        // Test 4: Overwrite register x5
        @(posedge clk);
        rd = 5'd5;
        writeData = 32'h12345678;
        writeEnable = 1;

        @(posedge clk);
        writeEnable = 0;
        rs1 = 5'd5;
        #2;
        if (readData1 == 32'h12345678)
            $display("[PASS] Test 4: x5 successfully overwritten");
        else
            $display("[FAIL] Test 4: Overwrite failed");

        // Test 5: Reset behavior
        @(posedge clk);
        rst = 1;
        @(posedge clk);
        rst = 0;
        rs1 = 5'd5;
        #2;
        if (readData1 == 32'h0)
            $display("[PASS] Test 5: Reset cleared registers successfully");
        else
            $display("[FAIL] Test 5: Reset failed");

        #20;
        $finish;
    end
endmodule