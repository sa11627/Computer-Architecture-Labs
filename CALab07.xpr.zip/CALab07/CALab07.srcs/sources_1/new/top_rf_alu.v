module top_rf_alu (
    input wire clk,
    input wire rst_btn,
    input wire [15:0] switches,
    output wire [15:0] leds
);

    wire rst;
    debouncer d1 (.clk(clk), .pbin(rst_btn), .pbout(rst));

    // Internal FSM and Datapath signals
    reg [2:0] state;
    reg [3:0] op_step;
    reg rf_we;
    reg [4:0] rs1, rs2, rd;
    reg [31:0] writeData;
    wire [31:0] readData1, readData2;
    reg [3:0] alu_ctrl;
    wire [31:0] alu_result;
    wire zero_flag;

    // Instantiate Register File and ALU
    RegisterFile rf (
        .clk(clk), .rst(rst), .writeEnable(rf_we),
        .rs1(rs1), .rs2(rs2), .rd(rd),
        .writeData(writeData), .readData1(readData1), .readData2(readData2)
    );

    ALU alu (
        .A(readData1), .B(readData2), .ALUControl(alu_ctrl),
        .ALUResult(alu_result), .Zero(zero_flag)
    );

    // FSM Controller for FPGA demonstration sequence
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= 3'd0;
            op_step <= 4'd0;
        end else begin
            case (state)
                3'd0: begin // Initialization / Write Constants
                    rf_we <= 1'b1;
                    if (op_step == 0)      {rd, writeData} = {5'd1, 32'h10101010};
                    else if (op_step == 1) {rd, writeData} = {5'd2, 32'h01010101};
                   
                    if (op_step < 1) op_step <= op_step + 1;
                    else begin op_step <= 0; state <= 3'd1; end
                end
                3'd1: begin // Execute ALU operations based on switches
                    rf_we <= 1'b0;
                    rs1 <= 5'd1;
                    rs2 <= 5'd2;
                    alu_ctrl <= switches[3:0]; // Use bottom 4 switches to select ALU operation
                    state <= 3'd2;
                end
                3'd2: begin
                    rf_we <= 1'b1;
                    rd <= 5'd4;
                    writeData <= alu_result;
                    state <= 3'd1;
                end
            endcase
        end
    end

    // Map lower 16 bits of ALU result and FSM state to LEDs
    assign leds = {state, 9'b0, alu_result[3:0]};

endmodule