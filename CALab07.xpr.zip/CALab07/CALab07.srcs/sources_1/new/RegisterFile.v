module RegisterFile (
    input wire clk,
    input wire rst,
    input wire writeEnable,
    input wire [4:0] rs1,
    input wire [4:0] rs2,
    input wire [4:0] rd,
    input wire [31:0] writeData,
    output wire [31:0] readData1,
    output wire [31:0] readData2
);

    // 32 registers, each 32 bits wide
    reg [31:0] rf [31:0];
    integer i;

    // Asynchronous read ports with x0 hardwired to 0
    assign readData1 = (rs1 == 5'b0) ? 32'b0 : rf[rs1];
    assign readData2 = (rs2 == 5'b0) ? 32'b0 : rf[rs2];

    // Synchronous write port
    always @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin
                rf[i] <= 32'b0;
            end
        end else if (writeEnable && (rd != 5'b0)) begin
            rf[rd] <= writeData;
        end
    end

endmodule
