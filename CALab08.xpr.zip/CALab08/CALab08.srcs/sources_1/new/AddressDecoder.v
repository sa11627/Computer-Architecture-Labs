module AddressDecoder (
    input [31:0] address,
    input readEnable,
    input writeEnable,
    output reg DataMemSelect,
    output reg LEDSelect,
    output reg SwitchSelect,
    output reg DataMemRead,
    output reg DataMemWrite,
    output reg LEDWrite,
    output reg SwitchReadEnable
);
    always @(*) begin
        // Default assignments
        DataMemSelect    = 0;
        LEDSelect        = 0;
        SwitchSelect     = 0;
        DataMemRead      = 0;
        DataMemWrite     = 0;
        LEDWrite         = 0;
        SwitchReadEnable = 0;

        case (address[9:8])
            2'b00: begin // Data Memory (0 - 511)
                DataMemSelect = 1;
                DataMemRead   = readEnable;
                DataMemWrite  = writeEnable;
            end
            2'b01: begin // LEDs (512 - 767)
                LEDSelect     = 1;
                LEDWrite      = writeEnable;
            end
            2'b10: begin // Switches (768 - 1023)
                SwitchSelect  = 1;
                SwitchReadEnable = readEnable;
            end
            default: begin
                // Unused memory space
            end
        endcase
    end
endmodule


