module DataMemory (
    input clk,
    input MemWrite,
    input MemRead,
    input [31:0] address,
    input [31:0] write_data,
    output reg [31:0] read_data
);
    // 512 words x 32 bits data memory array
    reg [31:0] mem [0:511];

    // Synchronous write
    always @(posedge clk) begin
        if (MemWrite)
            mem[address[8:0]] <= write_data;
    end

    // Asynchronous read
    always @(*) begin
        if (MemRead)
            read_data = mem[address[8:0]];
        else
            read_data = 32'b0;
    end
endmodule