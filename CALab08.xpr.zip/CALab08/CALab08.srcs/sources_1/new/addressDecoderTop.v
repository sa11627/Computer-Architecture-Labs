module addressDecoderTop(
    input clk, rst,
    input [31:0] address,
    input readEnable, writeEnable,
    input [31:0] writeData,
    input [15:0] switches,
    output [31:0] readData,
    output [15:0] leds
);
    wire DataMemSelect, LEDSelect, SwitchSelect;
    wire DataMemRead, DataMemWrite, LEDWrite, SwitchReadEnable;
    wire [31:0] mem_read_data;

    // Instantiate Address Decoder
    AddressDecoder decoder (
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .DataMemSelect(DataMemSelect),
        .LEDSelect(LEDSelect),
        .SwitchSelect(SwitchSelect),
        .DataMemRead(DataMemRead),
        .DataMemWrite(DataMemWrite),
        .LEDWrite(LEDWrite),
        .SwitchReadEnable(SwitchReadEnable)
    );

    // Instantiate Data Memory
    DataMemory dmem (
        .clk(clk),
        .MemWrite(DataMemWrite),
        .MemRead(DataMemRead),
        .address(address),
        .write_data(writeData),
        .read_data(mem_read_data)
    );

    // LED Register Logic (Mapped to 512-767)
    reg [15:0] led_reg;
    always @(posedge clk or posedge rst) begin
        if (rst)
            led_reg <= 16'b0;
        else if (LEDSelect && LEDWrite)
            led_reg <= writeData[15:0];
    end
    assign leds = led_reg;

    // Read Data Multiplexer
    assign readData = SwitchSelect ? {16'b0, switches} :
                      (DataMemSelect ? mem_read_data : 32'b0);

endmodule

