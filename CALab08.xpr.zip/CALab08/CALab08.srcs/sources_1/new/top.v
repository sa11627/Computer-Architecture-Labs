`timescale 1ns / 1ps

module top(
 input clk,            // Basys 3 100MHz clock on pin W5
    input btnR,           // Reset push button on pin U18
    input [15:0] sw,      // 16 Slide switches
    output [15:0] led     // 16 LEDs
);
    wire clk_100mhz;
    wire rst;
    wire [15:0] debounced_switches;
    
    // Debounce the reset button
    debouncer rst_db (
        .clk(clk),
        .pbin(btnR),
        .pbout(rst)
    );

    // Debounce or pass switches (using Lab 5 switch handling if needed)
    // For direct mapping or synchronized switches:
    assign debounced_switches = sw;

    // Signals for the Memory System Address Decoder Top
    reg [31:0] address;
    reg readEnable;
    reg writeEnable;
    reg [31:0] writeData;
    wire [31:0] readData;
    wire [15:0] decoded_leds;

    // Instantiate Address Decoder Top Module from Task 2
    addressDecoderTop mem_sys_top (
        .clk(clk),
        .rst(rst),
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(debounced_switches),
        .readData(readData),
        .leds(decoded_leds)
    );

    // Interactive Hardware Testing Logic:
    // Use switches to configure address and data for interactive board testing, 
    // or implement the Lab 8 FSM state machine to cycle through operations.
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            address     <= 32'h0;
            writeEnable <= 1'b0;
            readEnable  <= 1'b1;
            writeData   <= 32'h0;
        end else begin
            // Example mapping for interactive testing using Basys 3 switches:
            // sw[9:8] selects the device region (00: DataMem, 01: LEDs, 10: Switches)
            // sw[7:0] selects the local address offset
            address     <= {22'b0, sw[9:8], 8'h04}; 
            writeData   <= {16'b0, sw[15:0]};
            writeEnable <= sw[0]; // Use switch 0 as a manual write trigger toggle
            readEnable  <= ~sw[0];
        end
    end

    // Drive board LEDs (shows lower 16 bits of read data or direct LED register)
    assign led = decoded_leds | readData[15:0];
    
endmodule
