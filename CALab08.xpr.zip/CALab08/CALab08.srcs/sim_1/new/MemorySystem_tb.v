`timescale 1ns / 1ps

module MemorySystem_tb;
    reg clk;
    reg rst;
    reg [31:0] address;
    reg readEnable;
    reg writeEnable;
    reg [31:0] writeData;
    reg [15:0] switches;
    wire [31:0] readData;
    wire [15:0] leds;

    // Instantiate Top-Level Module
    addressDecoderTop uut (
        .clk(clk),
        .rst(rst),
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(switches),
        .readData(readData),
        .leds(leds)
    );

    // Clock generation (100 MHz)
    always #5 clk = ~clk;

    initial begin
        // Initialize Signals
        clk = 0;
        rst = 1;
        address = 0;
        readEnable = 0;
        writeEnable = 0;
        writeData = 0;
        switches = 16'hA5A5;
        #20;
       
        rst = 0;
        #10;

        // 1. Test Data Memory Write (Address 0x04)
        address = 32'h00000004;
        writeData = 32'h12345678;
        writeEnable = 1;
        readEnable = 0;
        #10;
        writeEnable = 0;

        // 2. Test Data Memory Read (Address 0x04)
        readEnable = 1;
        #10;
        readEnable = 0;

        // 3. Test LED Write (Address 0x200 = 512 decimal, within LED range)
        address = 32'h00000200;
        writeData = 32'h000003FF; // Write to lower 10 LEDs
        writeEnable = 1;
        #10;
        writeEnable = 0;

        // 4. Test Switch Read (Address 0x300 = 768 decimal, within Switch range)
        address = 32'h00000300;
        readEnable = 1;
        #10;
        readEnable = 0;

        #20;
        $finish;
    end
endmodule