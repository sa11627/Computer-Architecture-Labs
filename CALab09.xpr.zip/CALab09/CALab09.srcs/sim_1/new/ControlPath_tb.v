`timescale 1ns / 1ps

module ControlPath_tb;

    // Testbench Inputs
    reg [6:0] opcode;
    reg [2:0] funct3;
    reg [6:0] funct7;

    // Testbench Outputs
    wire       RegWrite;
    wire [1:0] ALUOp;
    wire       MemRead;
    wire       MemWrite;
    wire       ALUSrc;
    wire       MemtoReg;
    wire       Branch;
    wire [3:0] ALUControl_out;

    // Instantiate MainControl
    MainControl u_main_ctrl (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch)
    );

    // Instantiate ALUControl
    ALUControl u_alu_ctrl (
        .ALUOp      (ALUOp),
        .funct3     (funct3),
        .funct7     (funct7),
        .ALUControl (ALUControl_out)
    );

    integer pass_count = 0;
    integer fail_count = 0;

    // Verification Task
    task check_instruction(
        input [63:0] inst_name,
        input [6:0]  in_opcode,
        input [2:0]  in_funct3,
        input [6:0]  in_funct7,
        input        exp_RegWrite,
        input        exp_ALUSrc,
        input        exp_MemRead,
        input        exp_MemWrite,
        input        exp_MemtoReg,
        input        exp_Branch,
        input [3:0]  exp_ALUControl
    );
        begin
            opcode = in_opcode;
            funct3 = in_funct3;
            funct7 = in_funct7;
            #10; // Wait for combinational settling

            if (RegWrite       === exp_RegWrite &&
                ALUSrc         === exp_ALUSrc   &&
                MemRead        === exp_MemRead  &&
                MemWrite       === exp_MemWrite &&
                MemtoReg       === exp_MemtoReg &&
                Branch         === exp_Branch   &&
                ALUControl_out === exp_ALUControl) begin
                $display("[PASS] %s | opcode=%b funct3=%b funct7=%b | RegW=%b ALUSrc=%b MemR=%b MemW=%b M2R=%b Br=%b ALUOp=%b ALUCtrl=%b",
                         inst_name, opcode, funct3, funct7, RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch, ALUOp, ALUControl_out);
                pass_count = pass_count + 1;
            end else begin
                $display("[FAIL] %s | Expected: RegW=%b ALUSrc=%b MemR=%b MemW=%b M2R=%b Br=%b ALUCtrl=%b | Got: RegW=%b ALUSrc=%b MemR=%b MemW=%b M2R=%b Br=%b ALUCtrl=%b",
                         inst_name, exp_RegWrite, exp_ALUSrc, exp_MemRead, exp_MemWrite, exp_MemtoReg, exp_Branch, exp_ALUControl,
                         RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch, ALUControl_out);
                fail_count = fail_count + 1;
            end
        end
    endtask

    initial begin
        $display("==========================================================================================");
        $display("           Starting Lab 9 RISC-V Control Path Simulation Verification");
        $display("==========================================================================================");

        //                Name      opcode      funct3  funct7      RegW ALUSrc MemR MemW M2R  Br   ALUCtrl
        // 1. R-Type Instructions
        check_instruction("ADD     ", 7'b0110011, 3'b000, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0010);
        check_instruction("SUB     ", 7'b0110011, 3'b000, 7'b0100000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0110);
        check_instruction("SLL     ", 7'b0110011, 3'b001, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0100);
        check_instruction("SRL     ", 7'b0110011, 3'b101, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0101);
        check_instruction("AND     ", 7'b0110011, 3'b111, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0000);
        check_instruction("OR      ", 7'b0110011, 3'b110, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0001);
        check_instruction("XOR     ", 7'b0110011, 3'b100, 7'b0000000, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0011);

        // 2. I-Type Arithmetic Instruction
        check_instruction("ADDI    ", 7'b0010011, 3'b000, 7'b0000000, 1'b1, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0010);

        // 3. Load Instructions (I-Type)
        check_instruction("LW      ", 7'b0000011, 3'b010, 7'b0000000, 1'b1, 1'b1, 1'b1, 1'b0, 1'b1, 1'b0, 4'b0010);
        check_instruction("LH      ", 7'b0000011, 3'b001, 7'b0000000, 1'b1, 1'b1, 1'b1, 1'b0, 1'b1, 1'b0, 4'b0010);
        check_instruction("LB      ", 7'b0000011, 3'b000, 7'b0000000, 1'b1, 1'b1, 1'b1, 1'b0, 1'b1, 1'b0, 4'b0010);

        // 4. Store Instructions (S-Type)
        check_instruction("SW      ", 7'b0100011, 3'b010, 7'b0000000, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 4'b0010);
        check_instruction("SH      ", 7'b0100011, 3'b001, 7'b0000000, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 4'b0010);
        check_instruction("SB      ", 7'b0100011, 3'b000, 7'b0000000, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 4'b0010);

        // 5. Branch Instruction (B-Type)
        check_instruction("BEQ     ", 7'b1100011, 3'b000, 7'b0000000, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 4'b0110);

        // 6. Default / Invalid Opcode Test
        check_instruction("DEFAULT ", 7'b1111111, 3'b111, 7'b1111111, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 4'b0010);

        $display("==========================================================================================");
        $display("           Simulation Complete: %0d Passed, %0d Failed", pass_count, fail_count);
        $display("==========================================================================================");
        $finish;
    end

endmodule