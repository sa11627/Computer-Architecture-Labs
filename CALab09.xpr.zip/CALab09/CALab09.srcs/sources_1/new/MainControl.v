`timescale 1ns / 1ps

module MainControl (
    input  wire [6:0] opcode,
    output reg        RegWrite,
    output reg  [1:0] ALUOp,
    output reg        MemRead,
    output reg        MemWrite,
    output reg        ALUSrc,
    output reg        MemtoReg,
    output reg        Branch
);

    // RV32I Opcode Definitions
    localparam OP_R_TYPE = 7'b0110011; // ADD, SUB, SLL, SRL, AND, OR, XOR
    localparam OP_I_ALU  = 7'b0010011; // ADDI
    localparam OP_LOAD   = 7'b0000011; // LW, LH, LB
    localparam OP_STORE  = 7'b0100011; // SW, SH, SB
    localparam OP_BRANCH = 7'b1100011; // BEQ

    always @(*) begin
        // Default safe assignments (replaces don't-cares 'X' with 0 and prevents latches)
        RegWrite = 1'b0;
        ALUSrc   = 1'b0;
        MemRead  = 1'b0;
        MemWrite = 1'b0;
        MemtoReg = 1'b0;
        Branch   = 1'b0;
        ALUOp    = 2'b00;

        case (opcode)
            OP_R_TYPE: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b0;
                MemRead  = 1'b0;
                MemWrite = 1'b0;
                MemtoReg = 1'b0;
                Branch   = 1'b0;
                ALUOp    = 2'b10;
            end

            OP_I_ALU: begin // ADDI
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                MemRead  = 1'b0;
                MemWrite = 1'b0;
                MemtoReg = 1'b0;
                Branch   = 1'b0;
                ALUOp    = 2'b11; // Decodes I-type arithmetic in ALUControl
            end

            OP_LOAD: begin // LW, LH, LB
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                MemRead  = 1'b1;
                MemWrite = 1'b0;
                MemtoReg = 1'b1;
                Branch   = 1'b0;
                ALUOp    = 2'b00;
            end

            OP_STORE: begin // SW, SH, SB
                RegWrite = 1'b0;
                ALUSrc   = 1'b1;
                MemRead  = 1'b0;
                MemWrite = 1'b1;
                MemtoReg = 1'b0; // Don't care (X) assigned safe 0
                Branch   = 1'b0;
                ALUOp    = 2'b00;
            end

            OP_BRANCH: begin // BEQ
                RegWrite = 1'b0;
                ALUSrc   = 1'b0;
                MemRead  = 1'b0;
                MemWrite = 1'b0;
                MemtoReg = 1'b0; // Don't care (X) assigned safe 0
                Branch   = 1'b1;
                ALUOp    = 2'b01;
            end

            default: begin
                RegWrite = 1'b0;
                ALUSrc   = 1'b0;
                MemRead  = 1'b0;
                MemWrite = 1'b0;
                MemtoReg = 1'b0;
                Branch   = 1'b0;
                ALUOp    = 2'b00;
            end
        endcase
    end

endmodule