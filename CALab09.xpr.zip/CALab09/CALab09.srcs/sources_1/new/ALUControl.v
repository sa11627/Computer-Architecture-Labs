`timescale 1ns / 1ps

module ALUControl (
    input  wire [1:0] ALUOp,
    input  wire [2:0] funct3,
    input  wire [6:0] funct7,
    output reg  [3:0] ALUControl
);

    // 4-bit ALU Control Operation Encodings (Match with Lab 6 ALU.v)
    localparam ALU_AND = 4'b0000;
    localparam ALU_OR  = 4'b0001;
    localparam ALU_ADD = 4'b0010;
    localparam ALU_XOR = 4'b0011;
    localparam ALU_SLL = 4'b0100;
    localparam ALU_SRL = 4'b0101;
    localparam ALU_SUB = 4'b0110;

    always @(*) begin
        // Default safe assignment
        ALUControl = ALU_ADD;

        case (ALUOp)
            2'b00: begin
                // LW, LH, LB, SW, SH, SB (Address Calculation: ADD)
                ALUControl = ALU_ADD;
            end

            2'b01: begin
                // BEQ (Branch Comparison: SUB)
                ALUControl = ALU_SUB;
            end

            2'b10: begin
                // R-Type Instructions (ADD, SUB, SLL, SRL, AND, OR, XOR)
                case (funct3)
                    3'b000: begin
                        if (funct7 == 7'b0100000)
                            ALUControl = ALU_SUB; // SUB
                        else
                            ALUControl = ALU_ADD; // ADD (funct7 == 7'b0000000)
                    end
                    3'b001:  ALUControl = ALU_SLL; // SLL
                    3'b100:  ALUControl = ALU_XOR; // XOR
                    3'b101:  ALUControl = ALU_SRL; // SRL
                    3'b110:  ALUControl = ALU_OR;  // OR
                    3'b111:  ALUControl = ALU_AND; // AND
                    default: ALUControl = ALU_ADD; // Safe default
                endcase
            end

            2'b11: begin
                // I-Type Arithmetic Instructions (ADDI, etc.)
                case (funct3)
                    3'b000:  ALUControl = ALU_ADD; // ADDI
                    3'b001:  ALUControl = ALU_SLL; // SLLI (optional extension)
                    3'b100:  ALUControl = ALU_XOR; // XORI (optional extension)
                    3'b101:  ALUControl = ALU_SRL; // SRLI (optional extension)
                    3'b110:  ALUControl = ALU_OR;  // ORI  (optional extension)
                    3'b111:  ALUControl = ALU_AND; // ANDI (optional extension)
                    default: ALUControl = ALU_ADD;
                endcase
            end

            default: ALUControl = ALU_ADD;
        endcase
    end

endmodule


