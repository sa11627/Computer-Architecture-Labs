`timescale 1ns / 1ps

module TopControlPath_FPGA (
    input  wire        clk,        // 100 MHz Basys 3 Clock
    input  wire        rst_btn,    // Center Pushbutton (U18) for Reset
    input  wire [15:0] sw,         // Physical FPGA Switches [15:0]
    output wire [15:0] led         // Physical FPGA LEDs [15:0]
);

    // 1. Debounce the reset button using Lab 5 debouncer module
    wire rst;
    debouncer u_debouncer (
        .clk   (clk),
        .pbin  (rst_btn),
        .pbout (rst)
    );

    // 2. Signals for Lab 5 Switch & LED interface modules
    wire [31:0] sw_readData;
    reg         sw_readEnable;
    reg         led_writeEnable;
    reg  [31:0] led_writeData;
    wire [31:0] unused_readData;

    // Note: Per Lab 5 module definitions (manual pages 86-87),
    // module 'leds' reads the physical switch inputs into readData[15:0],
    // and module 'switches' writes writeData[15:0] to physical LEDs.
    leds u_switch_reader (
        .clk         (clk),
        .rst         (rst),
        .btns        (16'b0),
        .writeData   (32'b0),
        .writeEnable (1'b0),
        .readEnable  (sw_readEnable),
        .memAddress  (30'b0),
        .switches    (sw),
        .readData    (sw_readData)
    );

    switches u_led_driver (
        .clk         (clk),
        .rst         (rst),
        .writeData   (led_writeData),
        .writeEnable (led_writeEnable),
        .readEnable  (1'b0),
        .memAddress  (30'b0),
        .readData    (unused_readData),
        .leds        (led)
    );

    // 3. Latch switch fields via FSM
    reg [6:0] opcode_reg;
    reg [2:0] funct3_reg;
    reg [6:0] funct7_reg;

    // 4. Control Path Output Wires
    wire       RegWrite;
    wire [1:0] ALUOp;
    wire       MemRead;
    wire       MemWrite;
    wire       ALUSrc;
    wire       MemtoReg;
    wire       Branch;
    wire [3:0] ALUControl_out;

    // Instantiate MainControl
    MainControl u_main_control (
        .opcode   (opcode_reg),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch)
    );

    // Instantiate ALUControl
    ALUControl u_alu_control (
        .ALUOp      (ALUOp),
        .funct3     (funct3_reg),
        .funct7     (funct7_reg),
        .ALUControl (ALUControl_out)
    );

    // 5. Verification FSM
    localparam S_READ_SW    = 2'b01;
    localparam S_UPDATE_LED = 2'b10;

    reg [1:0] state, next_state;

    // Sequential State & Register Updates
    always @(posedge clk) begin
        if (rst) begin
            state      <= S_READ_SW;
            opcode_reg <= 7'b0000000;
            funct3_reg <= 3'b000;
            funct7_reg <= 7'b0000000;
        end else begin
            state <= next_state;
            if (state == S_READ_SW) begin
                opcode_reg <= sw_readData[6:0];
                funct3_reg <= sw_readData[9:7];
                funct7_reg <= {1'b0, sw_readData[15:10]}; // sw[15] maps to funct7[5]
            end
        end
    end

    // Combinational Next-State and Output Logic
    always @(*) begin
        sw_readEnable   = 1'b0;
        led_writeEnable = 1'b0;
        led_writeData   = 32'b0;
        next_state      = state;

        case (state)
            S_READ_SW: begin
                sw_readEnable = 1'b1;
                next_state    = S_UPDATE_LED;
            end

            S_UPDATE_LED: begin
                led_writeEnable = 1'b1;
                led_writeData   = {
                    16'b0,
                    2'b00,          // led[15:14]: Unused
                    state,          // led[13:12]: FSM State indicator
                    RegWrite,       // led[11]
                    ALUSrc,         // led[10]
                    MemRead,        // led[9]
                    MemWrite,       // led[8]
                    MemtoReg,       // led[7]
                    Branch,         // led[6]
                    ALUOp,          // led[5:4]
                    ALUControl_out  // led[3:0]
                };
                next_state = S_READ_SW;
            end

            default: begin
                next_state = S_READ_SW;
            end
        endcase
    end

endmodule
