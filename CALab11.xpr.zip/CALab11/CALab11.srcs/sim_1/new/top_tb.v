`timescale 1ns / 1ps

module top_tb;
    reg         clk;
    reg         rst;
    reg         PCSrc;
    reg  [31:0] instruction;
    reg  [15:0] switches;

    wire [15:0] leds;
    wire [31:0] pc_current;
    wire [31:0] pc_plus_4;
    wire [31:0] branch_target;
    wire [31:0] pc_next;
    wire [31:0] imm_out;

   TopLevelProcessor dut(
               .clk(clk),
               .rst(rst),
               .switches(switches),
               .resetButton(rst),
               .leds(leds)
   );

    // 100 MHz Clock (10 ns period)
    always #5 clk = ~clk;

    initial begin
        $display("=== Starting Task 1: PC, ImmGen, and Branch Datapath Verification ===");
        clk = 0;
        rst = 1;
//        PCSrc = 0;
//        instruction = 32'h0000_0013; // NOP (addi x0, x0, 0)

        #12;
        rst = 0; // Release reset -> PC starts at 0
        
        switches = 11;
        #100;
        
        switches = 17;
        #100;
        
        switches = 3;
        #100;
        
        switches = 9;
        #100;
//        // Test 1: I-type positive immediate (addi x5, x0, 25 -> imm = 25) & Sequential PC + 4
//        instruction = 32'h0190_0293;
//        PCSrc = 0;
//        #10;
//        $display("[T1] PC=%0d (exp 4) | I-Type (+25) Imm=%0d (exp 25)", $signed(pc_current), $signed(imm_out));

//        // Test 2: I-type negative immediate (addi x6, x0, -12 -> imm = -12) & Sequential PC + 4
//        instruction = 32'hFF40_0313;
//        PCSrc = 0;
//        #10;
//        $display("[T2] PC=%0d (exp 8) | I-Type (-12) Imm=%0d (exp -12)", $signed(pc_current), $signed(imm_out));

//        // Test 3: S-type immediate (sw x5, 512(x0) -> imm = 512) & Sequential PC + 4
//        instruction = 32'h2050_2023;
//        PCSrc = 0;
//        #10;
//        $display("[T3] PC=%0d (exp 12) | S-Type (512) Imm=%0d (exp 512)", $signed(pc_current), $signed(imm_out));

//        // Test 4: B-type forward branch (beq x5, x5, +16 bytes -> imm_out = 8, branch_target = 12 + 16 = 28)
//        instruction = 32'h0052_8863;
//        PCSrc = 1;
//        #10;
//        $display("[T4] Forward Branch Taken: PC=%0d (exp 28) | B-Type Imm=%0d (exp 8)", $signed(pc_current), $signed(imm_out));

//        // Test 5: B-type backward branch (beq x5, x5, -8 bytes -> imm_out = -4, branch_target = 28 - 8 = 20)
//        instruction = 32'hFE52_8CE3;
//        PCSrc = 1;
//        #10;
//        $display("[T5] Backward Branch Taken: PC=%0d (exp 20) | B-Type Imm=%0d (exp -4)", $signed(pc_current), $signed(imm_out));

//        // Resume sequential execution
//        PCSrc = 0;
//        #10;
//        $display("[T6] Sequential Resume: PC=%0d (exp 24)", $signed(pc_current));

//        $display("=== Task 1 Verification PASSED ===");
#5000;
        $finish;
    end
endmodule
