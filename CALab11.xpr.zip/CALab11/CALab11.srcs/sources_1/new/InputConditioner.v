`timescale 1ns/1ps
// Filter around the unchanged Lab 5 pass-through debouncer; 10ms at 1MHz.
module InputConditioner(input clk,pbin,output reg stable=0);
 (* ASYNC_REG="TRUE" *) reg sync1=0,sync2=0;
 reg [13:0] count=0;
 always @(posedge clk) begin
  sync1<=pbin;sync2<=sync1;
  if(sync2==stable)count<=0;
  else if(count==9999)begin stable<=sync2;count<=0;end
  else count<=count+1'b1;
 end
endmodule
