`timescale 1ns / 1ps

module immGen (
    input  wire [31:0] instruction,
    output reg  [31:0] imm_out
);
    wire [6:0] opcode = instruction[6:0];

    always @(*) begin
        case (opcode)
            // I-Type: ADDI, Logic/Shift Immediate (0010011) & Loads LW/LH/LB (0000011)
            7'b0010011,
            7'b0000011,
            7'b1100111: begin
                imm_out = {{20{instruction[31]}}, instruction[31:20]};
            end

            // S-Type: Stores SW/SH/SB (0100011)
            7'b0100011: begin
                imm_out = {{20{instruction[31]}}, instruction[31:25], instruction[11:7]};
            end

            // B-Type: Conditional Branches BEQ (1100011)
            // Note: Unshifted 12-bit signed immediate; branchAdder performs (imm_out << 1)
            7'b1100011: begin
                imm_out = {{20{instruction[31]}}, instruction[31], instruction[7],
                           instruction[30:25], instruction[11:8]};
            end

            default: begin
                imm_out = 32'h0000_0000;
            end
        endcase
    end
endmodule