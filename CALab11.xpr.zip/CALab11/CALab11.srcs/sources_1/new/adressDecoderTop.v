`timescale 1ns/1ps
module addressDecoderTop(input clk,rst,input [31:0] address,
 input readEnable,writeEnable,input [31:0] writeData,input [2:0] funct3,
 input [15:0] switches,input resetButton,output reg [31:0] readData,output [15:0] leds);
 wire ramRead,ramWrite,ledWrite,switchRead;
 wire [31:0] ramData,switchData,unused;
 wire [31:0] laneData=ramData>>(8*address[1:0]);
 AddressDecoder decoder(address,readEnable,writeEnable,ramRead,ramWrite,ledWrite,switchRead);
 DataMemory ram(clk,ramWrite && !rst,address,writeData,funct3,ramData);
 // Names follow the printed Lab 5 declarations, which label the interfaces backwards.
 switches led_interface(.clk(clk),.rst(rst),.writeData(writeData),
  .writeEnable(ledWrite && !rst),.readEnable(1'b0),
  .memAddress({24'b0,address[7:2]}),.readData(unused),.leds(leds));
 leds switch_interface(.clk(clk),.rst(rst),.btns({15'b0,resetButton}),
  .writeData(32'b0),.writeEnable(1'b0),.readEnable(switchRead),
  .memAddress({24'b0,address[7:2]}),.switches(switches),.readData(switchData));
 always @* begin
  readData=0;
  if(ramRead) case(funct3)
   0:readData={{24{laneData[7]}},laneData[7:0]};
   1:readData={{16{laneData[15]}},laneData[15:0]};
   2:readData=ramData; default:readData=0;
  endcase
  else if(switchRead) readData=(address[7:2]==1)?{31'b0,resetButton}:switchData;
 end
endmodule
