`timescale 1ns/1ps
// Numeric ranges from p101; fixes inconsistent address[9:8] labels on p102.
// Upper address bits intentionally ignored as specified by the local Lab 8 map.
module AddressDecoder(input [31:0] address,input readEnable,writeEnable,
 output DataMemRead,DataMemWrite,LEDWrite,SwitchReadEnable);
 assign DataMemRead=readEnable && !address[9];
 assign DataMemWrite=writeEnable && !address[9];
 assign LEDWrite=writeEnable && address[9:8]==2'b10;
 assign SwitchReadEnable=readEnable && address[9:8]==2'b11;
endmodule
