`timescale 1ns/1ps
module RegisterFile(input clk,rst,RegWrite,input [4:0] rs1,rs2,rd,
 input [31:0] writeData,output [31:0] readData1,readData2);
 reg [31:0] regs[0:31]; integer i;
 always @(posedge clk) begin
  if(rst) for(i=0;i<32;i=i+1) regs[i]<=0;
  else if(RegWrite && rd!=0) regs[rd]<=writeData;
 end
 assign readData1=(rs1==0)?0:regs[rs1];
 assign readData2=(rs2==0)?0:regs[rs2];
endmodule
