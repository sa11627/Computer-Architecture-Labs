`timescale 1ns / 1ps

module branchAdder (
    input  wire [31:0] pc_in,
    input  wire [31:0] imm_in,
    output wire [31:0] branch_target
);
    assign branch_target = pc_in + (imm_in << 1);
endmodule