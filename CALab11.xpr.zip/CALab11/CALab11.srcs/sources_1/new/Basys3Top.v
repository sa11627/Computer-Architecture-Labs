`timescale 1ns/1ps
module Basys3Top #(parameter MEMFILE="countdownn.mem")(input clk,btnU,btnC,input [15:0] sw,output [15:0] led);
 // 100 MHz /100 = 1 MHz. This is clock generation, not a visible countdown delay.
 reg [5:0] divider=0; reg divided=0;
 always @(posedge clk) if(divider==49) begin divider<=0; divided<=~divided; end
 else divider<=divider+1'b1;
 wire cpu_clk;
`ifdef SYNTHESIS
 BUFG clock_buffer(.I(divided),.O(cpu_clk));
`else
 assign cpu_clk=divided;
`endif
 (* ASYNC_REG="TRUE" *) reg [1:0] resetSync=2'b11;
 always @(posedge cpu_clk or posedge btnU)
  if(btnU) resetSync<=2'b11; else resetSync<={resetSync[0],1'b0};
 (* ASYNC_REG="TRUE" *) reg [15:0] sw1=0,sw2=0;
 always @(posedge cpu_clk) begin sw1<=sw; sw2<=sw1; end
 wire softReset,filteredButton;
 InputConditioner conditioning(clk,btnC,filteredButton);
 debouncer button_filter(.clk(cpu_clk),.pbin(filteredButton),.pbout(softReset));
 TopLevelProcessor #(.MEMFILE(MEMFILE)) cpu(.clk(cpu_clk),.rst(resetSync[1]),.switches(sw2),
  .resetButton(softReset),.leds(led),.debugPC(),.debugInstruction(),.debugWriteData(),.fault());
endmodule
