`timescale 1ns/1ps
// Byte array from Lab 10. Four little-endian bytes form each instruction.
module instructionMemory #(parameter OPERAND_LENGTH=31,BYTES=256,MEMFILE="countdownn.mem")
 (input [OPERAND_LENGTH:0] instAddress,output reg [31:0] instruction,output fault);
 reg [7:0] memory[0:BYTES-1]; integer i;
 initial begin
  for(i=0;i<BYTES;i=i+4) begin
   memory[i]=8'h13; memory[i+1]=0; memory[i+2]=0; memory[i+3]=0;
  end
  if(MEMFILE!="") $readmemh(MEMFILE,memory);
 end
 assign fault=(instAddress[1:0]!=0 || instAddress>BYTES-4);
 always @* begin
  instruction=32'h00000013;
  if(!fault) instruction={memory[instAddress+3],memory[instAddress+2],memory[instAddress+1],memory[instAddress]};
 end
endmodule
