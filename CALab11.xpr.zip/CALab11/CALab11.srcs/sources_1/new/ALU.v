`timescale 1ns/1ps
module ALU(input [31:0] a,b,input [2:0] ALUControl,output reg [31:0] result,output zero);
 // 0 ADD, 1 SUB, 2 SLL, 3 SRL, 4 AND, 5 OR, 6 XOR
 always @* case(ALUControl)
  0:result=a+b; 1:result=a-b; 2:result=a<<b[4:0]; 3:result=a>>b[4:0];
  4:result=a&b; 5:result=a|b; 6:result=a^b; default:result=0;
 endcase
 assign zero=(result==0);
endmodule
