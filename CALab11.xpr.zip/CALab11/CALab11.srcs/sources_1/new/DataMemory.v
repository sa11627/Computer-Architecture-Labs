`timescale 1ns/1ps
module DataMemory(input clk,MemWrite,input [31:0] address,write_data,
 input [2:0] funct3,output [31:0] read_data);
 // 512x32 as requested; 512-byte window exposes only first 128 words.
 (* ram_style="distributed" *) reg [31:0] memory[0:511]; integer i;
 initial for(i=0;i<512;i=i+1) memory[i]=0;
 wire [8:0] wordAddress={2'b00,address[8:2]};
 assign read_data=memory[wordAddress];
 always @(posedge clk) if(MemWrite) case(funct3)
  0:case(address[1:0])
   0:memory[wordAddress][7:0]<=write_data[7:0];
   1:memory[wordAddress][15:8]<=write_data[7:0];
   2:memory[wordAddress][23:16]<=write_data[7:0];
   3:memory[wordAddress][31:24]<=write_data[7:0];
  endcase
  1:if(address[1]) memory[wordAddress][31:16]<=write_data[15:0];
    else memory[wordAddress][15:0]<=write_data[15:0];
  2:memory[wordAddress]<=write_data;
 endcase
endmodule
