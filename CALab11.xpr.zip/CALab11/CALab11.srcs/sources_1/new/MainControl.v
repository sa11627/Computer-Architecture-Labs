`timescale 1ns/1ps
module MainControl(input [6:0] opcode,
 output reg RegWrite,ALUSrc,MemRead,MemWrite,MemtoReg,Branch,Jump,Jalr,
 output reg [1:0] ALUOp,output reg validOpcode);
 always @* begin
  RegWrite=0; ALUSrc=0; MemRead=0; MemWrite=0; MemtoReg=0;
  Branch=0; Jump=0; Jalr=0; ALUOp=0; validOpcode=1;
  case(opcode)
   7'h33:begin RegWrite=1; ALUOp=2; end
   7'h13:begin RegWrite=1; ALUSrc=1; ALUOp=3; end
   7'h03:begin RegWrite=1; ALUSrc=1; MemRead=1; MemtoReg=1; end
   7'h23:begin ALUSrc=1; MemWrite=1; end
   7'h63:begin Branch=1; ALUOp=1; end
   7'h6f:begin Jump=1; RegWrite=1; end
   7'h67:begin Jump=1; Jalr=1; RegWrite=1; ALUSrc=1; end
   default:validOpcode=0;
  endcase
 end
endmodule
