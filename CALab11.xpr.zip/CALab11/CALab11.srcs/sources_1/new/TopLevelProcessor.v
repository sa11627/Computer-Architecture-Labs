`timescale 1ns/1ps
module TopLevelProcessor #(parameter MEMFILE="countdownn.mem",IMEM_BYTES=256)
 (input clk,rst,input [15:0] switches,input resetButton,
 output [15:0] leds,output [31:0] debugPC,debugInstruction,debugWriteData,output fault);
 wire [31:0] PC,PCPlus4,imm,branchTarget,branchNext,jumpTarget,flowNext,nextPC;
 wire [31:0] instruction,rs1Data,rs2Data,aluB,aluResult,memData,writeBack;
 wire RegWrite,ALUSrc,MemRead,MemWrite,MemtoReg,Branch,Jump,Jalr;
 wire [1:0] ALUOp; wire [2:0] aluControl;
 wire validOpcode,validALU,zero,romFault;
 wire [2:0] funct3=instruction[14:12];
 wire loadStoreValid=(funct3==0 || funct3==1 || funct3==2);
 wire encodingOK=validOpcode && validALU &&
  (!(MemRead || MemWrite) || loadStoreValid) && (!Jalr || funct3==0);
 wire dataMisaligned=(MemRead || MemWrite) &&
  ((funct3==1 && aluResult[0]) || (funct3==2 && aluResult[1:0]!=0));
 wire PCSrc=Branch && ((funct3==0 && zero) || (funct3==1 && !zero));
 wire [31:0] jalrTarget=(aluResult & 32'hfffffffe);
 wire badNow=!encodingOK || dataMisaligned || romFault || flowNext[1:0]!=0;
 reg halted;
 always @(posedge clk) if(rst) halted<=0; else if(badNow) halted<=1;
 assign fault=halted || badNow;
 ProgramCounter pc_reg(clk,rst,nextPC,PC);
 pcAdder sequential_adder(PC,PCPlus4);
 immGen immediate_generator(instruction,imm);
 branchAdder branch_adder(PC,imm,branchTarget);
 mux2 pc_mux(PCPlus4,branchTarget,PCSrc,branchNext);
 assign jumpTarget=Jalr?jalrTarget:PC+imm;
 mux2 jump_mux(branchNext,jumpTarget,Jump,flowNext);
 assign nextPC=fault?PC:flowNext;
 instructionMemory #(.BYTES(IMEM_BYTES),.MEMFILE(MEMFILE)) imem(PC,instruction,romFault);
 MainControl main_control(instruction[6:0],RegWrite,ALUSrc,MemRead,MemWrite,
  MemtoReg,Branch,Jump,Jalr,ALUOp,validOpcode);
 ALUControl alu_control(ALUOp,funct3,instruction[31:25],aluControl,validALU);
 RegisterFile rf(clk,rst,RegWrite && !fault && !rst,instruction[19:15],
  instruction[24:20],instruction[11:7],writeBack,rs1Data,rs2Data);
 mux2 operand_mux(rs2Data,imm,ALUSrc,aluB);
 ALU arithmetic(rs1Data,aluB,aluControl,aluResult,zero);
 addressDecoderTop memory_system(clk,rst,aluResult,MemRead && !fault && !rst,
  MemWrite && !fault && !rst,rs2Data,funct3,switches,resetButton,memData,leds);
 assign writeBack=Jump?PCPlus4:(MemtoReg?memData:aluResult);
 assign debugPC=PC; assign debugInstruction=instruction; assign debugWriteData=writeBack;
endmodule
