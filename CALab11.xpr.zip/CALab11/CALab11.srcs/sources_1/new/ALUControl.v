`timescale 1ns/1ps
module ALUControl(input [1:0] ALUOp,input [2:0] funct3,input [6:0] funct7,
 output reg [2:0] control,output reg valid);
 always @* begin
  control=0; valid=1;
  case(ALUOp)
   0:control=0;
   1:begin control=1; valid=(funct3==0 || funct3==1); end
   3:begin control=0; valid=(funct3==0); end
   2:case({funct7,funct3})
    {7'h00,3'h0}:control=0; {7'h20,3'h0}:control=1;
    {7'h00,3'h1}:control=2; {7'h00,3'h5}:control=3;
    {7'h00,3'h7}:control=4; {7'h00,3'h6}:control=5;
    {7'h00,3'h4}:control=6; default:valid=0;
   endcase
   default:valid=0;
  endcase
 end
endmodule
