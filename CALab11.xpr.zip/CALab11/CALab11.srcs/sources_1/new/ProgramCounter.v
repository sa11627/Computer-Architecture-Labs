`timescale 1ns / 1ps

module ProgramCounter (
    input  wire        clk,
    input  wire        rst,
    input  wire [31:0] pc_in,
    output reg  [31:0] pc_out
);
    always @(posedge clk) begin
        if (rst)
            pc_out <= 32'h0000_0000;
        else
            pc_out <= pc_in;
    end
endmodule